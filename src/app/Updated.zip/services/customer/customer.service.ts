import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../../models/customer.model';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  private baseUrl = 'https://localhost:7155/api/User';

  constructor(private http: HttpClient) {}

  getCustomerById(id: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/${id}`);
  }

  updateCustomer(id: string, payload: Partial<Customer>): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, payload);
  }
  
}


