import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CustomerService } from '../../../services/customer/customer.service';
import { Customer } from '../../../models/customer.model';
import { CommonModule, DatePipe } from '@angular/common';
import { AccountSidebarComponent } from '../components/account-sidebar/account-sidebar.component';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, AccountSidebarComponent],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  providers: [DatePipe] // ✅ You need this for date formatting
})
export class ProfileComponent implements OnInit {
  profileForm!: FormGroup;
  createdDate: string = '';
  lastLogin: string = '';

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private datePipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      firstName: [''],
      lastName: [''],
      email: [''],
      mobileCode: [''],
      mobileNumber: [''],
      address: [''],
      city: [''],
      region: [''],
      postalCode: [''],
      country: [''],
      role: ['']
    });

    this.loadCustomer();
  }

  loadCustomer(): void {
    const id = '3fa85f64-5717-4562-b3fc-2c963f66afa6';
    this.customerService.getCustomerById(id).subscribe((data: Customer) => {
      this.profileForm.patchValue({
        firstName: data.firstName.value,
        lastName: data.lastName.value,
        email: data.email,
        mobileCode: data.mobileCode,
        mobileNumber: data.mobileNumber,
        address: data.address,
        city: data.city,
        region: data.region,
        postalCode: data.postalCode,
        country: data.country,
        role: data.role
      });

      // ✅ Store formatted dates
      this.createdDate = this.datePipe.transform(data.createdDate, 'MMM d, y, h:mm a') || '';
      this.lastLogin = this.datePipe.transform(data.lastLoginDate, 'MMM d, y, h:mm a') || '';
    });
  }

  onSave(): void {
    if (!this.profileForm.dirty) {
      alert('No changes to save!');
      return;
    }
  
    const id = '3fa85f64-5717-4562-b3fc-2c963f66afa6'; // or get from route/token
    const updatedProfile = this.profileForm.value;
  
    this.customerService.updateCustomer(id, updatedProfile).subscribe({
      next: () => {
        alert('Profile updated successfully ✅');
        this.editMode = {
          email: false,
          phone: false,
          dob: false,
          name: false
        };
      },
      error: () => {
        alert('Failed to update profile ❌');
      }
    });
  }
  
  
  editMode = {
    name: false,
    email: false,
    phone: false,
    dob: false
  };
  
}
