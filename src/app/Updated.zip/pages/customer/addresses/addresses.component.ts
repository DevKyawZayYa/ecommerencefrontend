import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../../services/customer/customer.service';
import { Customer } from '../../../models/customer.model';
import { AccountSidebarComponent } from '../components/account-sidebar/account-sidebar.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-addresses',
  standalone: true,
  imports: [CommonModule,FormsModule,AccountSidebarComponent],
  templateUrl: './addresses.component.html',
  styleUrls: ['./addresses.component.css']
})
export class AddressesComponent implements OnInit {
  user: Customer | null = null;
  editMode = false; // ✅ NEW

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    const id = '3fa85f64-5717-4562-b3fc-2c963f66afa6';
    this.customerService.getCustomerById(id).subscribe((data) => {
      this.user = data;
    });
  }

  closeModal(): void {
    this.editMode = false;
  }
  
  onEdit(): void {
    console.log('Opening modal...');
    this.editMode = true;
  }
  
  
  

  onSaveAddress(): void {
    if (!this.user) return;

    const id = '3fa85f64-5717-4562-b3fc-2c963f66afa6';
    this.customerService.updateCustomer(id, this.user).subscribe({
      next: () => {
        alert('Address updated successfully ✅');
        this.editMode = false;
      },
      error: () => {
        alert('Something went wrong ❌');
      }
    });
  }
}

